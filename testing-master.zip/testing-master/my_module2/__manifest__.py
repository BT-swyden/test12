##############################################################################
#
# Copyright (c) 2017 brain-tec AG (http://www.braintec-group.com)
# All Right Reserved
#
# See LICENSE file for full licensing details.
##############################################################################
{
    'name': "My test module2",
    'summary': "My test module2",
    'author': "Silvan Wyden",
    'website': "http://www.braintec-group.com/",
    'category': 'Extra Tools',
    'version': '11.0.1.0.0',
    'license': 'LGPL-3',
    'depends': ['base'],
}
